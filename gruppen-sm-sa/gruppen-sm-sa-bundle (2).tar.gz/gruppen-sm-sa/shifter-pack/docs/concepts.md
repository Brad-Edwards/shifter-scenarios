# Concepts

Secret Manager and service accounts for GRUPPEN, emitted from the sanitized range-spec. Aliased; configuration and roles only.
