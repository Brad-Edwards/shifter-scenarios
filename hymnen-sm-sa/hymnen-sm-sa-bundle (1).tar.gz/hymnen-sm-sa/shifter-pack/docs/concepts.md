# Concepts

Secret Manager and service accounts for HYMNEN, emitted from the sanitized range-spec. Aliased; configuration and roles only.
