# Attack path

Emitted from the range-spec; the specific foothold and chain are chosen by the exercise author from the reproduced IAM.
