# HYMNEN - cyber range environment pack (Secret Manager + service accounts)

Gygax-emitted range bundle for the HYMNEN engagement, targeting GCP project `gygax-range-hymnen`. Built 2026-11-03 from Gygax commit `f387b64`. Supersedes the 2026-10-28 bundle. Identifiers are sanitizer aliases; no real project names, principal names, or secret values.

## What changed since the 2026-10-28 bundle

- **No outside identities.** Every principal the range can't build is now a stand-in service account inside `gygax-range-hymnen` (see Stand-ins). Nothing outside this project has to exist: no outside GCP project, users, groups, Workspace domain, workload identity pools, or domain-restricted sharing exception.
- **Project is preset.** `cloud-terraform/terraform.tfvars.json` sets `project = "gygax-range-hymnen"`, and Terraform loads it automatically, so no `-var` is needed.
- **APIs are enabled by the Terraform.** It declares `google_project_service` for secretmanager, iam, and cloudresourcemanager.
- **More IAM fidelity.** Conditional bindings, view and admin project roles, and admin roles on single service accounts are now carried over from the source.

## Why this is split in two

Shifter realizes VMs and networks, not IAM or Secret Manager. Shifter ingests the VM-only pack and builds the participant workstation. The cloud layer (service accounts, impersonation, Secret Manager, IAM bindings) is the Terraform in `cloud-terraform/`, applied into `gygax-range-hymnen`. Who runs that apply (Gygax or Shifter) is being settled between us.

## What is in this bundle

- `shifter-pack.tar.gz`: the RAES environment pack for Shifter tenant upload (pack.yaml at the archive root), the VM-only participant workstation. Validated with raes-env-packs `validate_pack` and Shifter's `validate_pack_contract`.
- `shifter-pack/`: the same pack, extracted.
- `cloud-terraform/main.tf.json`: the GCP cloud layer for `gygax-range-hymnen`. 172 service accounts (73 from the source plus 99 stand-ins), 1935 secrets with 1935 versions, 63 secret-level bindings, 101 project-level bindings, 47 bindings on service accounts (impersonation and admin), 3 API enablements, and a Data Access audit config. 4257 resources and data sources in total.
- `cloud-terraform/terraform.tfvars.json`: sets the target project.
- `canonical.sdl.yaml`: the full source-of-truth SDL, including the cloud model Shifter's SDL rejects. The shifter-pack SDL is a VM-only projection of it.
- `build-manifest.json`: every range-spec resource by uid, built (2008) or not built with a reason (4637), plus the 99 stand-ins.

## Stand-ins

99 principals from the source can't be built in a single range project: 57 users, 26 service accounts from other projects, 13 workload identity principal sets, 3 groups. Each one is a service account in `gygax-range-hymnen` named `x-<12 hex>`, holding the grants the original principal held here. `build-manifest.json` `stand_ins` records what each stand-in replaces (by sanitized alias). Every IAM member in the Terraform is therefore a service account the Terraform itself creates. Stand-in display names and the `stand-in-for` attribute carry sanitized source aliases; they are descriptive and don't change what gets built.

Known cost of stand-ins: detections keyed on principal type (user vs service account) won't fire as they would in production, and project-level roles that reach every service account also reach the stand-ins, a path production doesn't have.

## Applying the cloud layer

```sh
cd cloud-terraform
terraform init
terraform apply
```

- Runs as whatever Application Default Credentials are active. That identity needs to create service accounts, set project and service-account IAM, enable services, and manage Secret Manager in `gygax-range-hymnen`; Owner on the project covers all of it.
- Service account creation is rate-limited per project, so expect the apply to take several minutes. If it stops on a rate-limit error, run `terraform apply` again.
- Secret values come from the `secret_values` variable (a map of secret id to value). With none supplied, every secret gets a synthetic placeholder value.
- Keep the Terraform state that `apply` writes; teardown is `terraform destroy` from the same directory.

## The foothold

Not declared in the pack, and no credential ships here. Gygax mints a key for the chosen starting service account from the built range at exercise time, hands it to the Red Team, and deletes it afterward.

## Uploading to Shifter

Tenant-upload `shifter-pack.tar.gz` with pack name `hymnen-sm-sa` (must match pack.yaml's name).

## Caveats

- The shifter-pack and the Terraform target the same range project (`gygax-range-hymnen`); the scenario only makes sense with both applied there.
- Gygax's pre-apply checks passed on this build: leak check against the source mapping, every IAM member a built service account, no hard-coded project, no public members, no service account keys, SDL and Terraform consistent.
