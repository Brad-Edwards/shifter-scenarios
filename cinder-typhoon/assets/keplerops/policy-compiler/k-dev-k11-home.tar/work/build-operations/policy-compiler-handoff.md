# Policy compiler migration handoff

Release Engineering has made the retained policy-compiler migration repository
available through FieldKest Source. It appears in the authenticated repository
list as `fieldkest/policy-compiler`. Use the source credential already saved in
Git and the workstation CA. The repository README contains the migration and
acceptance-service procedures.
