# FieldKest package and compatibility services

The developer credential already saved for the source service is accepted by
the package engineering APIs. Use the workstation CA for TLS.

The active connector metadata is at
`GET https://packages.keplerops.test/@keplerops%2ffieldlink-connector`.
The team's checked-in consumer request is `consumer-request.json`; submit it to
`POST /api/consumer-checks` as JSON.

Release archive records use `GET /api/releases/{release_id}`. Package/tenant
reconciliation uses `POST /api/reconcile/tenant-package`, and isolated resolver
runs use `POST /api/resolver/runs`.

Importer requests use `POST /api/imports`. Package publication uses the same
encoded package path as metadata with `PUT`; publisher credentials are scoped
to the `arwc-stable` connector channel. Package views use
`GET /api/package-views/{view}/{encoded-package-name}`.

Inspector requests use `POST /api/inspections`, traces use
`GET /api/inspections/{inspection_id}/trace`, and binary compatibility
envelopes use `POST /api/inspections/envelope` with
`application/octet-stream`. `inspection-normal.json` and
`inspection-compat.fki` are retained engineering fixtures.

Legacy entitlement records use
`GET /api/compatibility/entitlements/{entitlement_id}`. Validation uses
`POST /api/compatibility/entitlements/check` with JSON fields `checker`,
`record`, and `context`. The archived release record carries the companion
derivation context for its retained entitlement.
