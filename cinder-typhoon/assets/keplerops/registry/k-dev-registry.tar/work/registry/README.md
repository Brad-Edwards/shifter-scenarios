# FieldKest packages and delivery services

Node.js and npm are installed on the developer workstation. Its private npm
configuration selects the internal registry and workstation CA. Rowan can read
ordinary packages; publication requires the release publisher account.

Use the registry UI at `https://packages.keplerops.test/`, or normal npm
commands to inspect versions, README files, manifests, and tarballs:

```sh
npm view @keplerops/fieldlink-connector versions --json
npm view @keplerops/fieldlink-connector@7.4.2
npm pack @keplerops/fieldlink-connector@7.4.2
```

Install a selected version with `npm install`. Publish a new package version
with `npm publish` under the appropriate account. The registry rejects a
duplicate version. Customer release approval is a separate delivery operation.

FieldLink delivery and compatibility services are at
`https://delivery.keplerops.test:8443`. Their client reference is
`/.well-known/fieldkest-client`.

The team's checked-in consumer request is `consumer-request.json`. Submit it
to `POST /api/consumer-checks` to select the configured connector range and
run its actual installed module in the isolated consumer. The result identifies
the consumed package version and digest alongside the produced observations.

Release records use `GET /api/releases/{release_id}`. Package and customer
reconciliation uses `POST /api/reconcile/tenant-package`.

Inspector requests use `POST /api/inspections`, traces use
`GET /api/inspections/{inspection_id}/trace`, and binary compatibility
envelopes use `POST /api/inspections/envelope` with
`application/octet-stream`. `inspection-normal.json` and
`inspection-compat.fki` are retained engineering inputs.

Legacy entitlement records use
`GET /api/compatibility/entitlements/{entitlement_id}`. Validation uses
`POST /api/compatibility/entitlements/check` with JSON fields `checker`,
`record`, and `context`. The archived release record carries the companion
derivation context for its retained entitlement.
