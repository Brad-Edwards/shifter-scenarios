# Connector archive review

The retained `fieldkest/connector-archive` repository is available from FieldKest Source with the saved developer credential. Compare the ordinary and signed diagnostic examples; the repository note describes the authenticated embedded module.
