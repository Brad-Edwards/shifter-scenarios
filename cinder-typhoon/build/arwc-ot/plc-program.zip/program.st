FUNCTION_BLOCK OutletControl
  VAR_INPUT
    PositionRaw : UINT;
    FlowRaw : UINT;
    BasePermit : BOOL;
    LowLevel : BOOL;
    Armed : BOOL;
    AutoMode : BOOL;
    FlowSetting : REAL;
    ManualTarget : REAL;
    ResetFault : BOOL;
  END_VAR
  VAR_OUTPUT
    PositionPct : REAL;
    FlowM3s : REAL;
    TargetRaw : UINT;
    EnableCoil : BOOL;
    Permissive : BOOL;
    Moving : BOOL;
    AtTarget : BOOL;
    TravelFault : BOOL;
    MotionState : UINT;
  END_VAR
  VAR
    FlowLoop : PID;
    TravelTimer : TON;
    ReverseTimer : TON;
    ResetEdge : R_TRIG;
    EffectiveTarget : REAL;
    ErrorPct : REAL;
    DesiredDirection : INT;
    LastDirection : INT;
    Reversing : BOOL;
    Automatic : BOOL;
    Saturated : BOOL;
    Regulating : BOOL;
  END_VAR

  PositionPct := UINT_TO_REAL(PositionRaw) / 100.0;
  FlowM3s := UINT_TO_REAL(FlowRaw) / 10000.0;
  Permissive := BasePermit AND PositionRaw <= 10000 AND FlowRaw <= 5000;
  ResetEdge(CLK := ResetFault);
  IF ResetEdge.Q THEN
    TravelFault := FALSE;
  END_IF;

  (* Motorized outlets need a flow deadband, not continuous small reversals. *)
  IF NOT AutoMode OR NOT Armed OR NOT Permissive OR LowLevel OR TravelFault THEN
    Regulating := FALSE;
  ELSIF ABS(FlowSetting - FlowM3s) > 0.0075 THEN
    Regulating := TRUE;
  ELSIF ABS(FlowSetting - FlowM3s) <= 0.0025 THEN
    Regulating := FALSE;
  END_IF;
  Automatic := AutoMode AND Armed AND Permissive AND NOT LowLevel AND NOT TravelFault AND Regulating AND NOT Saturated;
  (* The native PID uses PV-SP. Negative gain and negative X0 track positive position. *)
  FlowLoop(AUTO := Automatic, PV := FlowM3s * 200.0, SP := FlowSetting * 200.0,
           X0 := -PositionPct, KP := -1.0, TR := 5.0, TD := 0.0, CYCLE := T#100ms);
  Saturated := Automatic AND (FlowLoop.XOUT < 0.0 OR FlowLoop.XOUT > 100.0);
  IF AutoMode THEN
    EffectiveTarget := LIMIT(0.0, FlowLoop.XOUT, 100.0);
  ELSE
    EffectiveTarget := LIMIT(0.0, ManualTarget, 100.0);
  END_IF;
  IF LowLevel THEN
    EffectiveTarget := 0.0;
  END_IF;
  IF AutoMode AND FlowSetting <= 0.0 THEN
    EffectiveTarget := 0.0;
  END_IF;
  TargetRaw := REAL_TO_UINT(EffectiveTarget * 100.0);
  ErrorPct := EffectiveTarget - PositionPct;
  AtTarget := ABS(ErrorPct) <= 0.5;
  IF TargetRaw = 0 THEN
    AtTarget := PositionRaw = 0;
  ELSIF TargetRaw >= 10000 THEN
    AtTarget := PositionRaw >= 10000;
  END_IF;
  DesiredDirection := 0;
  IF NOT AtTarget THEN
    IF ErrorPct > 0.0 THEN
      DesiredDirection := 1;
    ELSE
      DesiredDirection := -1;
    END_IF;
  END_IF;

  IF Armed AND Permissive AND NOT TravelFault THEN
    IF DesiredDirection * LastDirection = -1 THEN
      Reversing := TRUE;
    END_IF;
  ELSE
    Reversing := FALSE;
    LastDirection := 0;
  END_IF;
  ReverseTimer(IN := Reversing, PT := T#500ms);
  IF ReverseTimer.Q THEN
    Reversing := FALSE;
    LastDirection := DesiredDirection;
  END_IF;
  EnableCoil := Armed AND Permissive AND NOT TravelFault AND NOT AtTarget AND NOT Reversing;
  TravelTimer(IN := EnableCoil, PT := T#25s);
  IF TravelTimer.Q THEN
    TravelFault := TRUE;
    EnableCoil := FALSE;
  END_IF;
  IF EnableCoil THEN
    LastDirection := DesiredDirection;
  END_IF;
  Moving := EnableCoil;
  IF TravelFault THEN
    MotionState := 5;
  ELSIF NOT Permissive THEN
    MotionState := 4;
  ELSIF NOT Armed THEN
    MotionState := 0;
  ELSIF Reversing THEN
    MotionState := 6;
  ELSIF AtTarget THEN
    MotionState := 3;
  ELSIF DesiredDirection > 0 THEN
    MotionState := 1;
  ELSE
    MotionState := 2;
  END_IF;
END_FUNCTION_BLOCK

FUNCTION_BLOCK SiteInputs
  VAR_INPUT
    LevelRaw : UINT;
    Heartbeat : UINT;
  END_VAR
  VAR_OUTPUT
    LevelM : REAL;
    UsableVolumeML : REAL;
    IoHealthy : BOOL;
    LowLevelAlarm : BOOL;
  END_VAR
  VAR
    LastHeartbeat : UINT;
    Freshness : TON;
  END_VAR

  Freshness(IN := Heartbeat = LastHeartbeat, PT := T#3s);
  IoHealthy := (Heartbeat > 0) AND NOT Freshness.Q AND (LevelRaw <= 10000);
  LastHeartbeat := Heartbeat;
  LevelM := UINT_TO_REAL(LevelRaw) / 1000.0;
  UsableVolumeML := MAX(0.0, (LevelM - 1.0) * 2.0);
  IF LevelM <= 1.0 THEN
    LowLevelAlarm := TRUE;
  ELSIF LevelM >= 1.2 THEN
    LowLevelAlarm := FALSE;
  END_IF;
END_FUNCTION_BLOCK

FUNCTION_BLOCK SiteRequests
  VAR_INPUT
    IoHealthy : BOOL;
    AvailableA : BOOL;
    AvailableB : BOOL;
    LowLevel : BOOL;
    FaultA : BOOL;
    FaultB : BOOL;
    HmiStop : BOOL;
    RemoteEnableInput : BOOL;
    HmiTargetA : REAL;
    HmiTargetB : REAL;
    HmiAutoMode : BOOL;
    HmiFlow : REAL;
    HmiSequence : UINT;
    RemoteTargetA : REAL;
    RemoteTargetB : REAL;
    RemoteAutoMode : BOOL;
    RemoteFlow : REAL;
    RemoteSequence : UINT;
  END_VAR
  VAR_OUTPUT
    TargetA : REAL;
    TargetB : REAL;
    AutoMode : BOOL;
    FlowSetting : REAL;
    Armed : BOOL;
    RemoteEnabled : BOOL;
    Owner : UINT;
    HmiAccepted : UINT;
    RemoteAccepted : UINT;
    HmiRejected : UINT;
    RemoteRejected : UINT;
    HmiSeen : UINT;
    RemoteSeen : UINT;
    RejectReason : UINT;
    HmiRejectReason : UINT;
    RemoteRejectReason : UINT;
  END_VAR
  VAR RETAIN
    SavedA : REAL := 0.0;
    SavedB : REAL := 0.0;
    SavedFlow : REAL := 0.2;
  END_VAR
  VAR
    HmiNew : BOOL;
    RemoteNew : BOOL;
    CandidateA : REAL;
    CandidateB : REAL;
    CandidateAuto : BOOL;
    CandidateFlow : REAL;
    CandidateSource : UINT;
    Reason : UINT;
    CandidateValid : BOOL;
  END_VAR

  HmiNew := HmiSequence <> HmiSeen;
  RemoteNew := RemoteSequence <> RemoteSeen;
  RemoteEnabled := RemoteEnableInput;
  CandidateSource := 0;

  (* Recovery never replays a request which arrived while the site was unavailable. *)
  IF NOT IoHealthy OR NOT AvailableA OR NOT AvailableB OR FaultA OR FaultB OR HmiStop THEN
    Armed := FALSE;
    RemoteEnabled := FALSE;
    Owner := 0;
  END_IF;

  (* A local request wins the entire two-outlet transaction. *)
  IF HmiNew THEN
    CandidateSource := 1;
    CandidateA := HmiTargetA;
    CandidateB := HmiTargetB;
    CandidateAuto := HmiAutoMode;
    CandidateFlow := HmiFlow;
    IF RemoteNew THEN
      RemoteRejected := RemoteSequence;
      RemoteRejectReason := 8;
      RejectReason := 8;
    END_IF;
  ELSIF RemoteNew THEN
    CandidateSource := 2;
    CandidateA := RemoteTargetA;
    CandidateB := RemoteTargetB;
    CandidateAuto := RemoteAutoMode;
    CandidateFlow := RemoteFlow;
  END_IF;

  IF CandidateSource <> 0 THEN
    CandidateValid := (CandidateA >= 0.0) AND (CandidateA <= 100.0)
        AND (CandidateB >= 0.0) AND (CandidateB <= 100.0)
        AND (CandidateFlow >= 0.0) AND (CandidateFlow <= 1.0);
    Reason := 0;
    IF NOT IoHealthy THEN
      Reason := 1;
    ELSIF NOT AvailableA OR NOT AvailableB THEN
      Reason := 2;
    ELSIF HmiStop THEN
      Reason := 6;
    ELSIF FaultA OR FaultB THEN
      Reason := 7;
    ELSIF (CandidateSource = 2) AND NOT RemoteEnabled THEN
      Reason := 5;
    ELSIF NOT CandidateValid THEN
      Reason := 4;
    ELSIF LowLevel AND ((CandidateAuto AND CandidateFlow > 0.0)
        OR (NOT CandidateAuto AND (CandidateA > 0.0 OR CandidateB > 0.0))) THEN
      Reason := 3;
    END_IF;
    IF Reason = 0 THEN
      SavedA := CandidateA;
      SavedB := CandidateB;
      SavedFlow := CandidateFlow;
      AutoMode := CandidateAuto;
      Armed := TRUE;
      Owner := CandidateSource;
      RejectReason := 0;
      IF CandidateSource = 1 THEN
        HmiAccepted := HmiSequence;
        HmiRejectReason := 0;
        RemoteEnabled := FALSE;
      ELSE
        RemoteAccepted := RemoteSequence;
        RemoteRejectReason := 0;
      END_IF;
    ELSE
      RejectReason := Reason;
      IF CandidateSource = 1 THEN
        HmiRejected := HmiSequence;
        HmiRejectReason := Reason;
      ELSE
        RemoteRejected := RemoteSequence;
        RemoteRejectReason := Reason;
      END_IF;
    END_IF;
  END_IF;

  HmiSeen := HmiSequence;
  RemoteSeen := RemoteSequence;
  TargetA := SavedA;
  TargetB := SavedB;
  FlowSetting := SavedFlow;
END_FUNCTION_BLOCK

PROGRAM main
  VAR
    LevelM : REAL;
    PositionPct : REAL;
    FlowM3s : REAL;
    HmiTargetPct : REAL;
    HmiSequence : UINT;
    HmiAccepted : UINT;
    HmiRemoteEnabled : BOOL;
    RemoteTargetPct : REAL;
    RemoteSequence : UINT;
    RemoteAccepted : UINT;
    RequestedTargetPct : REAL;
    IoHealthy : BOOL;
    Owner : UINT;
    UsableVolumeML : REAL;
    PositionBPct : REAL;
    FlowBM3s : REAL;
    TotalFlowM3s : REAL;
    HmiTargetBPct : REAL;
    HmiAutoMode : BOOL;
    HmiFlowM3s : REAL := 0.2;
    HmiStop : BOOL;
    HmiResetFaults : BOOL;
    RemoteTargetBPct : REAL;
    RemoteAutoMode : BOOL;
    RemoteFlowM3s : REAL := 0.2;
    RequestedTargetBPct : REAL;
    RequestedFlowM3s : REAL;
    AutoMode : BOOL;
    Armed : BOOL;
    HmiSeen : UINT;
    RemoteSeen : UINT;
    HmiRejected : UINT;
    RemoteRejected : UINT;
    RejectReason : UINT;
    HmiRejectReason : UINT;
    RemoteRejectReason : UINT;
    LowLevelAlarm : BOOL;
    PermissiveA : BOOL;
    PermissiveB : BOOL;
    MovingA : BOOL;
    MovingB : BOOL;
    TravelFaultA : BOOL;
    TravelFaultB : BOOL;
    AtTargetA : BOOL;
    AtTargetB : BOOL;
    MotionStateA : UINT;
    MotionStateB : UINT;
    ProjectRevision : UINT := 364;
    Inputs : SiteInputs;
    Requests : SiteRequests;
    OutletA : OutletControl;
    OutletB : OutletControl;
  END_VAR
  VAR
    MotorEnableA AT %QX0.0 : BOOL;
    MotorEnableB AT %QX0.1 : BOOL;
    LevelRaw AT %IW0 : UINT;
    PositionRaw AT %IW1 : UINT;
    FlowRaw AT %IW2 : UINT;
    Heartbeat AT %IW3 : UINT;
    PositionBRaw AT %IW4 : UINT;
    FlowBRaw AT %IW5 : UINT;
    TargetRaw AT %QW0 : UINT;
    TargetBRaw AT %QW1 : UINT;
    AvailableARaw AT %IX0.0 : BOOL;
    AvailableBRaw AT %IX0.1 : BOOL;
    RemoteARaw AT %IX0.2 : BOOL;
    RemoteBRaw AT %IX0.3 : BOOL;
  END_VAR
  VAR
    _TMP_AND2_OUT : BOOL;
    _TMP_AND3_OUT : BOOL;
    _TMP_DIV5_OUT : REAL;
    _TMP_ADD8_OUT : REAL;
  END_VAR

  Inputs(LevelRaw := LevelRaw, Heartbeat := Heartbeat);
  LevelM := Inputs.LevelM;
  UsableVolumeML := Inputs.UsableVolumeML;
  IoHealthy := Inputs.IoHealthy;
  LowLevelAlarm := Inputs.LowLevelAlarm;
  _TMP_AND2_OUT := AND(Inputs.IoHealthy, AvailableARaw, RemoteARaw);
  _TMP_AND3_OUT := AND(Inputs.IoHealthy, AvailableBRaw, RemoteBRaw);
  Requests(IoHealthy := Inputs.IoHealthy, AvailableA := _TMP_AND2_OUT, AvailableB := _TMP_AND3_OUT, LowLevel := Inputs.LowLevelAlarm, FaultA := TravelFaultA, FaultB := TravelFaultB, HmiStop := HmiStop, RemoteEnableInput := HmiRemoteEnabled, HmiTargetA := HmiTargetPct, HmiTargetB := HmiTargetBPct, HmiAutoMode := HmiAutoMode, HmiFlow := HmiFlowM3s, HmiSequence := HmiSequence, RemoteTargetA := RemoteTargetPct, RemoteTargetB := RemoteTargetBPct, RemoteAutoMode := RemoteAutoMode, RemoteFlow := RemoteFlowM3s, RemoteSequence := RemoteSequence);
  RequestedTargetPct := Requests.TargetA;
  RequestedTargetBPct := Requests.TargetB;
  RequestedFlowM3s := Requests.FlowSetting;
  HmiRemoteEnabled := Requests.RemoteEnabled;
  AutoMode := Requests.AutoMode;
  Armed := Requests.Armed;
  Owner := Requests.Owner;
  HmiAccepted := Requests.HmiAccepted;
  RemoteAccepted := Requests.RemoteAccepted;
  HmiRejected := Requests.HmiRejected;
  RemoteRejected := Requests.RemoteRejected;
  HmiSeen := Requests.HmiSeen;
  RemoteSeen := Requests.RemoteSeen;
  RejectReason := Requests.RejectReason;
  HmiRejectReason := Requests.HmiRejectReason;
  RemoteRejectReason := Requests.RemoteRejectReason;
  _TMP_DIV5_OUT := DIV(Requests.FlowSetting, 2.0);
  OutletA(PositionRaw := PositionRaw, FlowRaw := FlowRaw, BasePermit := _TMP_AND2_OUT, LowLevel := Inputs.LowLevelAlarm, Armed := Requests.Armed, AutoMode := Requests.AutoMode, FlowSetting := _TMP_DIV5_OUT, ManualTarget := Requests.TargetA, ResetFault := HmiResetFaults);
  PositionPct := OutletA.PositionPct;
  FlowM3s := OutletA.FlowM3s;
  TargetRaw := OutletA.TargetRaw;
  MotorEnableA := OutletA.EnableCoil;
  PermissiveA := OutletA.Permissive;
  MovingA := OutletA.Moving;
  AtTargetA := OutletA.AtTarget;
  TravelFaultA := OutletA.TravelFault;
  MotionStateA := OutletA.MotionState;
  OutletB(PositionRaw := PositionBRaw, FlowRaw := FlowBRaw, BasePermit := _TMP_AND3_OUT, LowLevel := Inputs.LowLevelAlarm, Armed := Requests.Armed, AutoMode := Requests.AutoMode, FlowSetting := _TMP_DIV5_OUT, ManualTarget := Requests.TargetB, ResetFault := HmiResetFaults);
  PositionBPct := OutletB.PositionPct;
  FlowBM3s := OutletB.FlowM3s;
  TargetBRaw := OutletB.TargetRaw;
  MotorEnableB := OutletB.EnableCoil;
  PermissiveB := OutletB.Permissive;
  MovingB := OutletB.Moving;
  AtTargetB := OutletB.AtTarget;
  TravelFaultB := OutletB.TravelFault;
  MotionStateB := OutletB.MotionState;
  _TMP_ADD8_OUT := ADD(OutletA.FlowM3s, OutletB.FlowM3s);
  TotalFlowM3s := _TMP_ADD8_OUT;
END_PROGRAM


CONFIGURATION Config0

  RESOURCE Res0 ON PLC
    TASK task0(INTERVAL := T#100ms,PRIORITY := 1);
    PROGRAM instance0 WITH task0 : main;
  END_RESOURCE
END_CONFIGURATION
